#!/usr/bin/env bash
set -euo pipefail

# Requires: wrangler (npm i -g wrangler) and Cloudflare account (wrangler login)

echo "==> Creating KV namespace (CACHE) if missing"
wrangler kv namespace create CACHE || true

echo "==> Creating D1 database BlazeDB if missing"
wrangler d1 create BlazeDB || true

echo "==> Creating R2 bucket blaze-media if missing"
wrangler r2 bucket create blaze-media || true

echo "==> Writing vars (edit as needed)"
# wrangler secret put CFB_API_KEY
# wrangler secret put ODDS_API_KEY

echo "==> Deploying Worker"
npm run deploy

echo "==> Deploying landing page to Cloudflare Pages"
wrangler pages deploy ./web --project-name blaze-unified

echo "==> Remember to set a Route for your domain in wrangler.toml or Dashboard (e.g., blazeintel.ai/*)"
