CREATE TABLE IF NOT EXISTS teams (
  id TEXT PRIMARY KEY,
  name TEXT,
  league TEXT,
  conference TEXT
);
CREATE TABLE IF NOT EXISTS players (
  id TEXT PRIMARY KEY,
  name TEXT,
  team_id TEXT,
  pos TEXT,
  marketability REAL,
  nil_est REAL
);
CREATE TABLE IF NOT EXISTS games (
  id TEXT PRIMARY KEY,
  league TEXT,
  season INT,
  week INT,
  home_id TEXT,
  away_id TEXT,
  start TIMESTAMP,
  status TEXT,
  home_score INT,
  away_score INT
);
CREATE TABLE IF NOT EXISTS odds (
  game_id TEXT,
  book TEXT,
  moneyline_home INT,
  moneyline_away INT,
  spread REAL,
  total REAL,
  ts TIMESTAMP,
  PRIMARY KEY (game_id, book)
);
CREATE INDEX IF NOT EXISTS games_by_league_time ON games (league, start);
