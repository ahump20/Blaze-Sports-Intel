# Blaze Intelligence — Unified Edge + Web

This repo bundles:
- Cloudflare Worker (unified router + sports API)
- Web landing page (`/web/index.html`) adapted from your uploaded `improved.html`

## Quickstart

1) Install deps
```bash
npm i
```

2) Configure Cloudflare
- Set `account_id`, KV/D1/R2 bindings in `wrangler.toml`
- Create a **KV** namespace (CACHE), **D1** database (BlazeDB), **R2** bucket (blaze-media)
- Set `CFB_API_KEY` and `ODDS_API_KEY` in `wrangler.toml` or via `wrangler secret put`

3) Deploy the Worker
```bash
npm run deploy
```

4) Point DNS to Cloudflare and add a route to your domain (e.g., `blazeintel.ai/*`).

5) Deploy landing page to Cloudflare Pages or any static host, and keep `/` routed to `WEB_ORIGIN`.
   (Defaults to https://blaze-io.pages.dev; you can publish `web/` as a Pages project and update `WEB_ORIGIN`.)

6) Test endpoints
- `GET /api/scoreboard/ncaa`
- `GET /api/odds/nfl`
- `GET /api/mlb/games/today`

7) Wire your other apps
- `/hq/*` → Netlify HQ (keep your Netlify CI)
- `/vision/*` → Cloudflare Pages
- `/public/*` → Public profile site

## Local dev
```bash
npm run dev
# open http://127.0.0.1:8787
```

## Notes
- Respect data provider ToS.
- For live rooms, implement WebSocket logic in `ScoreHub` DO.
