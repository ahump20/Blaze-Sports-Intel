import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { cache } from 'hono/cache'

type Env = {
  CACHE: KVNamespace
  DB: D1Database
  MEDIA: R2Bucket
  ScoreHub: DurableObjectNamespace
  INGEST: Queue
  CFB_API_KEY: string
  ODDS_API_KEY: string
  WEB_ORIGIN?: string
  HQ_ORIGIN?: string
  VISION_ORIGIN?: string
  PUBLIC_ORIGIN?: string
}

const app = new Hono<{ Bindings: Env }>()
app.use('*', cors())

// -------- Origins (configure via wrangler vars or defaults) --------
const DEFAULTS = {
  WEB_ORIGIN: 'https://blaze-io.pages.dev',
  HQ_ORIGIN: 'https://blaze-intelligence.netlify.app',
  VISION_ORIGIN: 'https://blaze-vision-intelligence.pages.dev',
  PUBLIC_ORIGIN: 'https://austin-humphrey-public.pages.dev'
}

function upstream(c: any, target: string) {
  const url = new URL(c.req.url)
  const u = new URL(url.pathname, target)
  u.search = url.search
  return fetch(u.toString(), { headers: c.req.raw.headers as any, cf: { cacheTtl: 300 } })
}

app.all('/', async c => {
  const origin = c.env.WEB_ORIGIN || DEFAULTS.WEB_ORIGIN
  return upstream(c, origin)
})

app.all('/hq/*', async c => upstream(c, c.env.HQ_ORIGIN || DEFAULTS.HQ_ORIGIN))
app.all('/vision/*', async c => upstream(c, c.env.VISION_ORIGIN || DEFAULTS.VISION_ORIGIN))
app.all('/public/*', async c => upstream(c, c.env.PUBLIC_ORIGIN || DEFAULTS.PUBLIC_ORIGIN))

// -------- API --------
const ttl = 30

app.get('/api/scoreboard/ncaa', cache({ cacheName: 'ncaa', cacheControl: `max-age=${ttl}` }), async c => {
  const key = 'ncaa:scoreboard:now'
  const hit = await c.env.CACHE.get(key)
  if (hit) return c.json(JSON.parse(hit))
  const resp = await fetch('https://api.collegefootballdata.com/games?year=2025&seasonType=regular', {
    headers: { Authorization: `Bearer ${c.env.CFB_API_KEY}` }
  })
  const data = await resp.json()
  await c.env.CACHE.put(key, JSON.stringify(data), { expirationTtl: ttl })
  return c.json(data)
})

app.get('/api/odds/nfl', async c => {
  const url = `https://api.the-odds-api.com/v4/sports/americanfootball_nfl/odds?regions=us&oddsFormat=american&apiKey=${c.env.ODDS_API_KEY}`
  const r = await fetch(url)
  return c.json(await r.json())
})

app.get('/api/mlb/games/today', async c => {
  const r = await fetch('https://statsapi.mlb.com/api/v1/schedule?sportId=1&date=today')
  return c.json(await r.json())
})

app.get('/api/media/:key', async c => {
  const key = c.req.param('key')
  const head = await c.env.MEDIA.head(key)
  if (!head) return c.notFound()
  const body = await c.env.MEDIA.get(key)
  return new Response(body?.body, { headers: { 'content-type': head.httpMetadata?.contentType || 'application/octet-stream' } })
})

// -------- Durable Object stub (extend later) --------
export class ScoreHub {
  constructor(readonly state: DurableObjectState, readonly env: Env) {}
  async fetch(_req: Request) {
    return new Response('OK')
  }
}

export default app
