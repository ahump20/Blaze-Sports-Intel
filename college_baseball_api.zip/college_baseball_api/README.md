# College Baseball API (Blaze Intelligence)

**What this does**

- **Real-time-ish scores & stat summaries** for NCAA Division I baseball (with ESPN/NCAA adapters + JSON normalization).
- **Rosters** (2025 & 2026) scraped from official school sites (adapters for SIDEARM Sports and WMT Digital).
- **Weekly Top-25/Top-30 polls aggregation** from **D1Baseball**, **Baseball America**, **USA TODAY Coaches**, **NCBWA**, **Perfect Game** (with optional Collegiate Baseball placeholder). 
- **Composite rankings** with defensible, transparent weighting and reproducible math.

> ⚠️ **Data, rights, and fair use**: This server fetches public pages to extract standings/polls/rosters. Respect each publisher’s Terms of Use and robots.txt before deploying commercially. For enterprise use, license official feeds.

---

## Quickstart

```bash
# Python 3.10+ recommended
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Run
uvicorn app.main:app --reload --port 8080
# then open http://localhost:8080/docs
```

### Docker

```bash
docker build -t college-baseball-api .
docker run -p 8080:8080 college-baseball-api
```

---

## Endpoints (v1)

- `GET /v1/scores?date=YYYY-MM-DD&provider=auto`  
  Returns normalized scoreboard for the date. Providers tried in order: NCAA JSON, ESPN hidden API.  
- `GET /v1/games/{event_id}/summary?provider=espn`  
  Normalized game summary/box if provider supports it (ESPN recommended).  
- `GET /v1/teams/{slug}/roster?season=2025&source_url=`  
  Returns normalized roster. If `source_url` provided, adapter is inferred from domain (SIDEARM/WMT).  
- `GET /v1/polls/{provider}?season=2025`  
  `{provider}` in `{d1baseball, baseballamerica, usatoday, ncbwa, perfectgame}`  
- `GET /v1/polls/composite?season=2025&method=weighted`  
  Aggregates available polls into one table with point-based normalization.
- `GET /healthz`

OpenAPI docs available at `/docs` and JSON at `/openapi.json`.

---

## Providers & Citations

- **Scores/Stats**  
  - NCAA scoreboard public pages + JSON (`data.ncaa.com/casablanca/carmen`) when available; HTML fallback.  
  - ESPN hidden API for college baseball scoreboard + per-event summary (unofficial).  
- **Polls**  
  - D1Baseball Top 25 (NCAA carries the list).  
  - Baseball America Top 25 (final and weekly pages).  
  - USA TODAY Sports Baseball Coaches Poll.  
  - NCBWA weekly polls (SportsWriters.net/NCBWA and ncbwa.com).  
  - Perfect Game D1 Top 25.  
- **Rosters**  
  - SIDEARM Sports roster pages (widespread in D1).  
  - WMT Digital roster pages (e.g., Texas, LSU, etc.).

---

## Environment

| var | default | description |
|-----|---------|-------------|
| `HTTP_TIMEOUT` | 15 | seconds per request |
| `CACHE_TTL_SCORES` | 30 | seconds |
| `CACHE_TTL_POLLS` | 14400 | 4 hours |
| `CACHE_TTL_ROSTER` | 86400 | 24 hours |
| `USER_AGENT` | BlazeCollegeBaseballAPI/0.1 | polite UA |

---

## Composite Ranking math

Each poll is converted to points where **rank 1 = N points**, **rank N = 1 point** (N = list length, usually 25 or 30). Points are **normalized to [0,1]** and multiplied by a provider weight (defaults below). Team scores are summed across providers; ties broken by highest best-rank then alphabetical.

Default weights:

- D1Baseball: 1.00
- Baseball America: 1.00
- USA TODAY Coaches: 1.00
- NCBWA (Top‑30): 0.90
- Perfect Game: 0.85
- Collegiate Baseball (if used): 0.85

You can alter weights via querystring (e.g. `...&w_d1=1.2&w_pg=0.7`).

---

## Notes

- **AP does not publish a college baseball poll**; use USA TODAY Coaches, D1Baseball, BA, NCBWA, Perfect Game, and (optionally) Collegiate Baseball Newspaper instead.
- If a page blocks scraping or changes structure, the adapter will return an error with `source` and `hint`. You can supply a `source_url` directly for rosters to override auto discovery.

---

## License

MIT (see LICENSE). This project is provided “as is” without warranties. Use at your own risk and in accordance with source sites’ terms.
