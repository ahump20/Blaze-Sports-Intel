from typing import Dict, List, Tuple
from collections import defaultdict
from app.models.polls import Poll, CompositePoll, CompositeEntry

def to_points(rank: int, n: int) -> int:
    return max(n - rank + 1, 0)

def composite(
    season: int,
    polls: List[Poll],
    weights: Dict[str, float] | None = None,
    method: str = "weighted",
) -> CompositePoll:
    if not weights:
        weights = {
            "d1baseball": 1.0,
            "baseballamerica": 1.0,
            "usatoday": 1.0,
            "ncbwa": 0.9,
            "perfectgame": 0.85,
            "collegiatebaseball": 0.85,
        }
    team_scores: Dict[str, float] = defaultdict(float)
    best_rank: Dict[str, int] = defaultdict(lambda: 10_000)
    detail: Dict[str, Dict[str, float]] = defaultdict(dict)
    for poll in polls:
        prov = poll.provider
        w = float(weights.get(prov, 1.0))
        n = max((e.rank for e in poll.entries), default=25)
        denom = float(n) if n else 25.0
        for e in poll.entries:
            pts = to_points(e.rank, n)
            norm = (pts / denom) * w
            team_scores[e.team] += norm
            best_rank[e.team] = min(best_rank[e.team], e.rank)
            detail[e.team][prov] = norm
    items: List[Tuple[str, float]] = [(t, s) for t, s in team_scores.items()]
    items.sort(key=lambda x: (-x[1], best_rank[x[0]], x[0]))
    entries = [
        CompositeEntry(team=t, score=round(s, 5), best_rank=best_rank[t], detail=detail[t])
        for t, s in items
    ]
    return CompositePoll(season=season, method=method, weights=weights, entries=entries)
