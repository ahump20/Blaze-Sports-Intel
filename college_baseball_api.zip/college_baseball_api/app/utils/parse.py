from bs4 import BeautifulSoup
from typing import Optional
import json

def soupify(html: str) -> BeautifulSoup:
    return BeautifulSoup(html, "lxml")

def first_json_ld(html: str) -> Optional[dict]:
    soup = soupify(html)
    tag = soup.find("script", {"type": "application/ld+json"})
    if not tag:
        return None
    try:
        return json.loads(tag.text)
    except Exception:
        return None
