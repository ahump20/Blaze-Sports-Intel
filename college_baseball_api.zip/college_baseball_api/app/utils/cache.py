from cachetools import TTLCache
from typing import Any

# Small in-process TTL caches. Tune sizes as needed.
scores_cache = TTLCache(maxsize=512, ttl=30)
polls_cache = TTLCache(maxsize=256, ttl=4*60*60)
roster_cache = TTLCache(maxsize=512, ttl=24*60*60)

def make_cache(maxsize: int, ttl: int):
    return TTLCache(maxsize=maxsize, ttl=ttl)
