import httpx
from app.config import settings

def client():
    return httpx.AsyncClient(
        timeout=settings.http_timeout,
        headers={
            "User-Agent": settings.user_agent,
            "Accept": "text/html,application/json;q=0.9,*/*;q=0.8",
        },
        follow_redirects=True,
        http2=True,
    )
