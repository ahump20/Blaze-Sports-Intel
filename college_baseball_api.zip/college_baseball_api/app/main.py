from fastapi import FastAPI
from fastapi.responses import ORJSONResponse
from app.routes import scores, games, rosters, polls, health

app = FastAPI(
    title="College Baseball API (Blaze Intelligence)",
    version="0.1.0",
    default_response_class=ORJSONResponse,
)

app.include_router(health.router, prefix="")
app.include_router(scores.router, prefix="/v1")
app.include_router(games.router, prefix="/v1")
app.include_router(rosters.router, prefix="/v1")
app.include_router(polls.router, prefix="/v1")
