import re
from fastapi import APIRouter, HTTPException, Query
from app.models.roster import Roster
from app.providers.rosters.sidearm import fetch_sidearm_roster
from app.providers.rosters.wmt import fetch_wmt_roster

router = APIRouter(tags=["rosters"])

def guess_adapter(url: str):
    u = url.lower()
    if "sidearmsports.com" in u:
        return "sidearm"
    if "texassports.com" in u or "lsusports.net" in u or u.endswith("/roster") or "/roster/" in u:
        return "wmt"
    return "sidearm"

@router.get("/teams/{slug}/roster", response_model=Roster)
async def get_roster(
    slug: str,
    season: int = Query(2025),
    source_url: str | None = Query(default=None, description="Direct roster URL (recommended)"),
):
    if not source_url:
        raise HTTPException(status_code=400, detail="Please pass ?source_url= to the roster page for reliability")
    adapter = guess_adapter(source_url)
    team_name = re.sub(r"[-_]+", " ", slug).title()
    if adapter == "sidearm":
        return await fetch_sidearm_roster(team_name, season, source_url)
    elif adapter == "wmt":
        return await fetch_wmt_roster(team_name, season, source_url)
    else:
        raise HTTPException(status_code=400, detail=f"Unsupported adapter for URL: {source_url}")
