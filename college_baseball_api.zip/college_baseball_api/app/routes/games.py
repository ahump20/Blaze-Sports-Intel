from fastapi import APIRouter, HTTPException, Query
from app.providers.scores.games_espn import fetch_espn_game_summary

router = APIRouter(tags=["games"])

@router.get("/games/{event_id}/summary")
async def game_summary(event_id: str, provider: str = Query(default="espn")):
    if provider != "espn":
        raise HTTPException(status_code=400, detail="Only provider=espn is supported for summaries now")
    data = await fetch_espn_game_summary(event_id)
    return data
