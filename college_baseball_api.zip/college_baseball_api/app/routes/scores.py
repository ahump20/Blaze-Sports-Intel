import datetime as dt
from fastapi import APIRouter, Query, HTTPException
from app.models.game import Game
from app.providers.scores.espn import fetch_espn_scoreboard
from app.providers.scores.ncaa import fetch_ncaa_scoreboard

router = APIRouter(tags=["scores"])

@router.get("/scores", response_model=list[Game])
async def get_scores(
    date: str = Query(default=None, description="YYYY-MM-DD; default: today (US/Eastern)"),
    provider: str = Query(default="auto", description="'auto'|'espn'|'ncaa'")
):
    try:
        target = dt.datetime.strptime(date, "%Y-%m-%d").date() if date else dt.date.today()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid date format. Use YYYY-MM-DD")
    if provider in ("auto", "ncaa"):
        games = await fetch_ncaa_scoreboard(target)
        if games:
            return games
        if provider == "ncaa":
            return []
    games = await fetch_espn_scoreboard(target)
    return games
