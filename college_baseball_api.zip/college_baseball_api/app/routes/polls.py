from fastapi import APIRouter, Query, HTTPException
from app.models.polls import Poll
from app.services.polls_service import composite as composite_calc
from app.providers.polls.d1 import fetch_d1baseball_top25
from app.providers.polls.ba import fetch_baseballamerica_top25
from app.providers.polls.usatoday import fetch_usatoday_coaches
from app.providers.polls.ncbwa import fetch_ncbwa
from app.providers.polls.pg import fetch_perfectgame_top25

router = APIRouter(tags=["polls"])

@router.get("/polls/{provider}", response_model=Poll)
async def get_poll(provider: str, season: int = Query(2025)):
    prov = provider.lower()
    if prov == "d1baseball":
        return await fetch_d1baseball_top25(season)
    elif prov == "baseballamerica":
        return await fetch_baseballamerica_top25(season)
    elif prov in ("usatoday", "coaches"):
        return await fetch_usatoday_coaches(season)
    elif prov == "ncbwa":
        return await fetch_ncbwa(season)
    elif prov == "perfectgame":
        return await fetch_perfectgame_top25(season)
    else:
        raise HTTPException(status_code=404, detail="Unknown provider")

@router.get("/polls/composite")
async def composite(
    season: int = Query(2025),
    w_d1: float = Query(1.0),
    w_ba: float = Query(1.0),
    w_usa: float = Query(1.0),
    w_ncbwa: float = Query(0.9),
    w_pg: float = Query(0.85),
    method: str = Query("weighted"),
):
    polls = []
    try:
        polls.append(await fetch_d1baseball_top25(season))
    except Exception:
        pass
    try:
        polls.append(await fetch_baseballamerica_top25(season))
    except Exception:
        pass
    try:
        polls.append(await fetch_usatoday_coaches(season))
    except Exception:
        pass
    try:
        polls.append(await fetch_ncbwa(season))
    except Exception:
        pass
    try:
        polls.append(await fetch_perfectgame_top25(season))
    except Exception:
        pass
    weights = {
        "d1baseball": w_d1,
        "baseballamerica": w_ba,
        "usatoday": w_usa,
        "ncbwa": w_ncbwa,
        "perfectgame": w_pg,
    }
    return composite_calc(season, polls, weights=weights, method=method)
