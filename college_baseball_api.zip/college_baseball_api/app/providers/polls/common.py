from typing import List
from app.models.polls import Poll, RankingEntry

def normalize_top_list(provider: str, season: int, names: List[str]) -> Poll:
    entries = [RankingEntry(rank=i+1, team=nm) for i, nm in enumerate(names)]
    return Poll(provider=provider, season=season, entries=entries)
