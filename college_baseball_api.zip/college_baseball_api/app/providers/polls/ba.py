import re
from app.utils.http import client
from app.utils.parse import soupify
from app.models.polls import Poll, RankingEntry

BA_URL = "https://www.baseballamerica.com/stories/college-baseball-top-25-rankings/"

async def fetch_baseballamerica_top25(season: int) -> Poll:
    async with client() as c:
        r = await c.get(BA_URL)
        r.raise_for_status()
        soup = soupify(r.text)
        entries = []
        # BA often renders as ol > li "1. Team"
        for i, li in enumerate(soup.select("ol li")[:25]):
            txt = li.get_text(" ", strip=True)
            team = re.sub(r"^\d+\.?\s*", "", txt)
            entries.append(RankingEntry(rank=i+1, team=team))
        if not entries:
            # Fallback: headings or paragraphs
            for i, p in enumerate(soup.select("p")[:25]):
                t = p.get_text(" ", strip=True)
                m = re.match(r"^\d+\.?\s*(.+)$", t)
                if m:
                    entries.append(RankingEntry(rank=len(entries)+1, team=m.group(1)))
                if len(entries) >= 25:
                    break
        return Poll(provider="baseballamerica", season=season, entries=entries)
