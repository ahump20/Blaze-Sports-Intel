import re
from typing import List
from app.utils.http import client
from app.utils.parse import soupify
from app.models.polls import Poll, RankingEntry

# NCAA carries a copy of D1Baseball Top 25 weekly page
NCAA_D1_TOP25 = "https://www.ncaa.com/rankings/baseball/d1/d1baseballcom-top-25"

async def fetch_d1baseball_top25(season: int) -> Poll:
    async with client() as c:
        r = await c.get(NCAA_D1_TOP25)
        r.raise_for_status()
        soup = soupify(r.text)
        entries: List[RankingEntry] = []
        # Find table rows with Rank and Team
        table = soup.find("table")
        if table:
            for i, tr in enumerate(table.select("tr")[1:26]):
                tds = [td.get_text(" ", strip=True) for td in tr.find_all("td")]
                if not tds:
                    continue
                team = tds[1] if len(tds) > 1 else tds[0]
                entries.append(RankingEntry(rank=i+1, team=team))
        else:
            # Try ordered list fallback
            ol = soup.find(["ol","ul"])
            if ol:
                for i, li in enumerate(ol.find_all("li", recursive=False)[:25]):
                    txt = li.get_text(" ", strip=True)
                    team = re.sub(r"^\d+\.?\s*", "", txt)
                    entries.append(RankingEntry(rank=i+1, team=team))
        return Poll(provider="d1baseball", season=season, entries=entries)
