import re
from app.utils.http import client
from app.utils.parse import soupify
from app.models.polls import Poll, RankingEntry

# Perfect Game example article (preseason). For in-season, swap to current article.
PG_RANK = "https://www.perfectgame.org/Articles/View.aspx?article=23355"

async def fetch_perfectgame_top25(season: int) -> Poll:
    async with client() as c:
        r = await c.get(PG_RANK)
        r.raise_for_status()
        soup = soupify(r.text)
        entries = []
        for li in soup.select("li"):
            txt = li.get_text(" ", strip=True)
            m = re.match(r"^(\d+)\.?\s+(.+)$", txt)
            if m:
                rank = int(m.group(1))
                team = m.group(2)
                if 1 <= rank <= 25:
                    entries.append(RankingEntry(rank=rank, team=team))
        entries = sorted(entries, key=lambda e: e.rank)[:25]
        return Poll(provider="perfectgame", season=season, entries=entries)
