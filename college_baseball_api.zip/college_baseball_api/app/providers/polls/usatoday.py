import re
from app.utils.http import client
from app.utils.parse import soupify
from app.models.polls import Poll, RankingEntry

USA_TODAY = "https://sportsdata.usatoday.com/baseball/cbb/coaches-poll"

async def fetch_usatoday_coaches(season: int) -> Poll:
    async with client() as c:
        r = await c.get(USA_TODAY)
        r.raise_for_status()
        soup = soupify(r.text)
        entries = []
        # Look for table rows with Rank, Team
        rows = soup.select("table tr")
        for tr in rows[1:26]:
            tds = [td.get_text(' ', strip=True) for td in tr.find_all("td")]
            if len(tds) >= 2 and tds[0].isdigit():
                rank = int(tds[0])
                team = tds[1]
                entries.append(RankingEntry(rank=rank, team=team))
        # Fallback: list items
        if not entries:
            for i, li in enumerate(soup.select("li")[:25]):
                txt = li.get_text(" ", strip=True)
                team = re.sub(r"^\d+\.?\s*", "", txt)
                entries.append(RankingEntry(rank=i+1, team=team))
        return Poll(provider="usatoday", season=season, entries=entries)
