from app.utils.http import client
from app.utils.parse import soupify
from app.models.polls import Poll, RankingEntry

# Use latest Division I poll article (SportsWriters/NCBWA)
NCBWA_LATEST_LIST = "https://www.sportswriters.net/ncbwa/news/category/polls"

async def fetch_ncbwa(season: int) -> Poll:
    async with client() as c:
        # Find the first article that mentions "Division I Poll"
        r = await c.get(NCBWA_LATEST_LIST)
        r.raise_for_status()
        soup = soupify(r.text)
        first_link = None
        for a in soup.select("a"):
            if a.get_text(strip=True).lower().endswith("division i poll"):
                first_link = a.get("href")
                break
        if not first_link:
            aa = soup.select("a")
            first_link = aa[0].get("href") if aa else NCBWA_LATEST_LIST
        r2 = await c.get(first_link)
        r2.raise_for_status()
        soup2 = soupify(r2.text)
        entries = []
        for tr in soup2.select("table tr")[1:31]:
            tds = [td.get_text(' ', strip=True) for td in tr.find_all("td")]
            if len(tds) >= 2 and tds[0].strip().isdigit():
                rank = int(tds[0].strip())
                team = tds[1].strip()
                entries.append(RankingEntry(rank=rank, team=team))
        return Poll(provider="ncbwa", season=season, entries=entries[:30])
