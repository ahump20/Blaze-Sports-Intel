import re
from typing import List
from app.utils.http import client
from app.utils.parse import soupify
from app.models.roster import Roster, RosterPlayer

async def fetch_wmt_roster(team: str, season: int, source_url: str) -> Roster:
    async with client() as c:
        r = await c.get(source_url)
        r.raise_for_status()
        soup = soupify(r.text)
        players: List[RosterPlayer] = []
        table = soup.find("table")
        if table:
            header = [th.get_text(" ", strip=True).lower() for th in table.find_all("th")]
            for tr in table.find_all("tr")[1:]:
                tds = [td.get_text(" ", strip=True) for td in tr.find_all("td")]
                if not tds:
                    continue
                pdata = dict(zip(header, tds))
                name = pdata.get("name") or pdata.get("full name") or (tds[1] if len(tds) > 1 else tds[0])
                players.append(RosterPlayer(
                    number=pdata.get("#") or pdata.get("no."),
                    name=name,
                    pos=pdata.get("pos") or pdata.get("position"),
                    class_year=pdata.get("class") or pdata.get("yr"),
                    height=pdata.get("ht") or pdata.get("height"),
                    weight=pdata.get("wt") or pdata.get("weight"),
                    bats_throws=pdata.get("b/t"),
                    hometown=pdata.get("hometown"),
                    previous_school=pdata.get("previous school") or pdata.get("last school"),
                ))
        if not players:
            for card in soup.select("[class*=Roster], [class*=roster], [class*=Card]"):
                txt = card.get_text(" ", strip=True)
                if not txt:
                    continue
                m = re.match(r"^(\d+)\s+([A-Za-z\-\.' ]+)", txt)
                nm = m.group(2) if m else txt
                players.append(RosterPlayer(name=nm))
        return Roster(team=team, season=season, source_url=source_url, players=players)
