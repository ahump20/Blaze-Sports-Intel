from typing import List
from app.utils.http import client
from app.utils.parse import soupify
from app.models.roster import Roster, RosterPlayer

async def fetch_sidearm_roster(team: str, season: int, source_url: str) -> Roster:
    async with client() as c:
        r = await c.get(source_url)
        r.raise_for_status()
        soup = soupify(r.text)
        players: List[RosterPlayer] = []
        table = soup.find("table")
        if table:
            header = [th.get_text(" ", strip=True).lower() for th in table.find_all("th")]
            for tr in table.find_all("tr")[1:]:
                tds = [td.get_text(" ", strip=True) for td in tr.find_all("td")]
                if not tds or len(tds) < 2:
                    continue
                pdata = dict(zip(header, tds))
                players.append(RosterPlayer(
                    number=pdata.get("#") or pdata.get("no.") or pdata.get("no"),
                    name=pdata.get("full name") or pdata.get("name") or tds[1],
                    pos=pdata.get("pos.") or pdata.get("pos") or pdata.get("position"),
                    class_year=pdata.get("academic year") or pdata.get("yr.") or pdata.get("yr"),
                    height=pdata.get("ht.") or pdata.get("height"),
                    weight=pdata.get("wt.") or pdata.get("weight"),
                    bats_throws=pdata.get("b/t") or pdata.get("b/t."),
                    hometown=pdata.get("hometown") or pdata.get("hometown / high school"),
                    previous_school=pdata.get("previous school") or pdata.get("high school"),
                ))
        else:
            for card in soup.select("[class*=roster], [class*=player-card]"):
                name = card.get_text(" ", strip=True)
                if name:
                    players.append(RosterPlayer(name=name))
        return Roster(team=team, season=season, source_url=source_url, players=players)
