import datetime as dt
from typing import List

from app.utils.http import client
from app.models.game import Game, TeamSide

ESPN_SCOREBOARD = "https://site.api.espn.com/apis/site/v2/sports/baseball/college-baseball/scoreboard"

async def fetch_espn_scoreboard(date: dt.date) -> List[Game]:
    '''
    ESPN hidden API. Use ?dates=YYYYMMDD to specify a date.
    '''
    ymd = date.strftime("%Y%m%d")
    params = {"dates": ymd}
    async with client() as c:
        r = await c.get(ESPN_SCOREBOARD, params=params)
        r.raise_for_status()
        data = r.json()
        out: List[Game] = []
        for ev in data.get("events", []):
            gid = ev.get("id")
            comp = (ev.get("competitions") or [{}])[0]
            status = comp.get("status", {}).get("type", {}).get("description", "TBD")
            home_t, away_t = None, None
            for ct in comp.get("competitors", []):
                ts = TeamSide(
                    id=str(ct.get("id")) if ct.get("id") else None,
                    name=ct.get("team", {}).get("displayName"),
                    abbreviation=ct.get("team", {}).get("abbreviation"),
                    record=(ct.get("records") or [{}])[0].get("summary") if ct.get("records") else None,
                    rank=(ct.get("curatedRank") or {}).get("current"),
                    score=_safe_int(ct.get("score")),
                    logo=(ct.get("team") or {}).get("logo")
                )
                if ct.get("homeAway") == "home":
                    home_t = ts
                else:
                    away_t = ts
            out.append(Game(
                id=str(gid),
                provider="espn",
                start=ev.get("date"),
                status=status,
                venue=(comp.get("venue") or {}).get("fullName"),
                away=away_t or TeamSide(name="Away"),
                home=home_t or TeamSide(name="Home"),
                inning=(comp.get("status") or {}).get("period"),
                linescore=None,
            ))
        return out

def _safe_int(v):
    try:
        return int(v)
    except Exception:
        return None
