from typing import Dict, Any
from app.utils.http import client

ESPN_SUMMARY = "https://site.api.espn.com/apis/site/v2/sports/baseball/college-baseball/summary"

async def fetch_espn_game_summary(event_id: str) -> Dict[str, Any]:
    params = {"event": event_id}
    async with client() as c:
        r = await c.get(ESPN_SUMMARY, params=params)
        r.raise_for_status()
        data = r.json()
        # Trim to a compact payload
        return {
            "id": event_id,
            "boxscore": data.get("boxscore"),
            "leaders": data.get("leaders"),
            "status": (data.get("header") or {}).get("competitions", [{}])[0].get("status")
        }
