import datetime as dt
from typing import List, Optional

from app.utils.http import client
from app.models.game import Game, TeamSide

NCAA_HTML_SCOREBOARD = "https://www.ncaa.com/scoreboard/baseball/d1/{y}/{m}/{d}"
NCAA_JSON_SCOREBOARD_TRY = [
    "https://data.ncaa.com/casablanca/scoreboard/baseball/d1/{y}/{m}/{d}/scoreboard.json",
    "https://data.ncaa.com/carmen/scoreboard/baseball/d1/{y}/{m}/{d}/scoreboard.json",
]

async def fetch_ncaa_scoreboard(date: dt.date) -> List[Game]:
    '''
    Try NCAA JSON endpoints first (casablanca/carmen). Fallback to parsing HTML page.
    '''
    y, m, d = f"{date.year}", f"{date.month:02d}", f"{date.day:02d}"
    async with client() as c:
        # Try JSON forms
        for url in NCAA_JSON_SCOREBOARD_TRY:
            u = url.format(y=y, m=m, d=d)
            try:
                r = await c.get(u)
                if r.status_code == 200 and "games" in r.text:
                    data = r.json()
                    return _normalize_ncaa_json(data)
            except Exception:
                pass

        # Fallback: HTML page (limited; structure may vary)
        u = NCAA_HTML_SCOREBOARD.format(y=y, m=m, d=d)
        r = await c.get(u)
        r.raise_for_status()
        # Minimal fallback: return empty if JSON not available
        return []

def _normalize_ncaa_json(data) -> List[Game]:
    out: List[Game] = []
    for g in data.get("games", []):
        game = g.get("game", {})
        away = game.get("away", {})
        home = game.get("home", {})
        status = game.get("contestStatus", {}).get("type", "")
        out.append(Game(
            id=str(game.get("id") or game.get("gameID") or ""),
            provider="ncaa",
            start=game.get("startTime"),
            status=status or "TBD",
            venue=game.get("venue", {}).get("fullName"),
            away=TeamSide(
                id=away.get("id"),
                name=away.get("names", {}).get("short") or away.get("names", {}).get("full") or "Away",
                abbreviation=away.get("names", {}).get("char6"),
                record=away.get("description"),
                rank=_safe_int(away.get("rank")),
                score=_safe_int(away.get("score")),
                logo=away.get("images", {}).get("logo_dark")
            ),
            home=TeamSide(
                id=home.get("id"),
                name=home.get("names", {}).get("short") or home.get("names", {}).get("full") or "Home",
                abbreviation=home.get("names", {}).get("char6"),
                record=home.get("description"),
                rank=_safe_int(home.get("rank")),
                score=_safe_int(home.get("score")),
                logo=home.get("images", {}).get("logo_dark")
            ),
            inning=None,
            linescore=None,
        ))
    return out

def _safe_int(v):
    try:
        return int(v)
    except Exception:
        return None
