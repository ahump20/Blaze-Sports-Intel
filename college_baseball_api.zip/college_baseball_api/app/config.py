from pydantic_settings import BaseSettings
from pydantic import Field

class Settings(BaseSettings):
    http_timeout: int = Field(default=15, alias="HTTP_TIMEOUT")
    cache_ttl_scores: int = Field(default=30, alias="CACHE_TTL_SCORES")
    cache_ttl_polls: int = Field(default=4*60*60, alias="CACHE_TTL_POLLS")
    cache_ttl_roster: int = Field(default=24*60*60, alias="CACHE_TTL_ROSTER")
    user_agent: str = Field(default="BlazeCollegeBaseballAPI/0.1 (+https://blaze-intelligence.netlify.app)", alias="USER_AGENT")

    class Config:
        extra = "ignore"
        env_file = ".env"

settings = Settings()
