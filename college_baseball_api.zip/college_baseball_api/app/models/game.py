from pydantic import BaseModel, Field
from typing import Optional, List, Dict

class TeamSide(BaseModel):
    id: Optional[str] = None
    name: str
    abbreviation: Optional[str] = None
    record: Optional[str] = None
    rank: Optional[int] = None
    score: Optional[int] = None
    logo: Optional[str] = None

class Game(BaseModel):
    id: str
    provider: str = Field(description="data source id e.g. 'espn' or 'ncaa'")
    start: Optional[str] = None
    status: str
    venue: Optional[str] = None
    home: TeamSide
    away: TeamSide
    inning: Optional[str] = None
    linescore: Optional[Dict[str, List[int]]] = None
