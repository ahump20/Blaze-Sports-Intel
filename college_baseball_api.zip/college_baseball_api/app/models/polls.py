from pydantic import BaseModel
from typing import List, Optional

class RankingEntry(BaseModel):
    rank: int
    team: str
    record: Optional[str] = None
    points: Optional[int] = None
    first_place: Optional[int] = None

class Poll(BaseModel):
    provider: str
    season: int
    date: Optional[str] = None
    entries: List[RankingEntry]

class CompositeEntry(BaseModel):
    team: str
    score: float
    best_rank: int
    detail: dict

class CompositePoll(BaseModel):
    season: int
    method: str
    weights: dict
    entries: List[CompositeEntry]
