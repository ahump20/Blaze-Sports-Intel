from pydantic import BaseModel
from typing import Optional, List

class RosterPlayer(BaseModel):
    number: Optional[str] = None
    name: str
    pos: Optional[str] = None
    class_year: Optional[str] = None
    height: Optional[str] = None
    weight: Optional[str] = None
    bats_throws: Optional[str] = None
    hometown: Optional[str] = None
    previous_school: Optional[str] = None
    bio_url: Optional[str] = None
    image_url: Optional[str] = None

class Roster(BaseModel):
    team: str
    season: int
    source_url: str
    players: List[RosterPlayer]
