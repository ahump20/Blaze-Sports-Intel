let listeners = [];
export function pushDashboardEvent(event) {
  listeners.forEach(cb => cb(event));
}
export function subscribeToTelemetry(cb) {
  listeners.push(cb);
  return () => listeners = listeners.filter(l => l !== cb);
}