export function toPromptFormat(analysisResult) {
  return {
    scenario: analysisResult.scenario || "Unknown Scenario",
    contextual_metrics: {
      decision_velocity: analysisResult.metrics?.decision_velocity || 0,
      collapse_threshold: analysisResult.metrics?.collapse_threshold || 0,
      comm_lag_ms: analysisResult.metrics?.comm_lag_ms || 0
    },
    protocol_triggers: analysisResult.triggers || []
  };
}