export function toPromptFormat(report, meta) {
  return {
    scenario: meta.timeframe.label,
    sport: meta.sport,
    team: meta.team,
    contextual_metrics: report.contextual_metrics,
    triggered_protocols: report.protocolsFired || [],
    feedback_request: {
      rate: ["execution precision", "mental recovery"],
      recall: "Describe the key shift during pressure.",
      sharpen: "What's your next micro-adjustment?"
    }
  };
}