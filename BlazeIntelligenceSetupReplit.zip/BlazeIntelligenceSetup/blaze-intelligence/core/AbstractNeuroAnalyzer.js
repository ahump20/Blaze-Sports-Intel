// Abstract base class for neurocognitive analysis across sports
export default class AbstractNeuroAnalyzer {
  constructor(gameData) {
    this.gameData = gameData;
  }

  analyzeCognitiveLoad() {
    // Stub method
  }
}
