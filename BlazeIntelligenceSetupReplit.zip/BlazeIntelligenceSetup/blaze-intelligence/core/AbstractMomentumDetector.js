// Abstract base class for momentum detection across sports
export default class AbstractMomentumDetector {
  constructor(gameData) {
    this.gameData = gameData;
  }

  detectMomentumShift() {
    // Stub method
  }
}
