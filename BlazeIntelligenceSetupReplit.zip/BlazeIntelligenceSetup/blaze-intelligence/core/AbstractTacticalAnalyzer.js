// Abstract base class for tactical analysis across sports
export default class AbstractTacticalAnalyzer {
  constructor(gameData) {
    this.gameData = gameData;
  }

  analyzeTactics() {
    // Stub method
  }
}
