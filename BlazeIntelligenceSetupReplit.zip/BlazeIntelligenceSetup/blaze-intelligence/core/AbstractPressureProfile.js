// Abstract base class for pressure analytics across sports
export default class AbstractPressureProfile {
  constructor(gameData) {
    this.gameData = gameData;
  }

  calculatePressureScore() {
    // Stub method
  }
}
